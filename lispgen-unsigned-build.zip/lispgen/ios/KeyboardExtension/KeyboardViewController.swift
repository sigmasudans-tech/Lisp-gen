import Flutter
import UIKit

final class KeyboardViewController: UIInputViewController {
  private var flutterEngine: FlutterEngine?
  private var keyboardChannel: FlutterMethodChannel?

  override func viewDidLoad() {
    super.viewDidLoad()

    view.backgroundColor = .systemBackground
    view.heightAnchor.constraint(equalToConstant: 270).isActive = true

    let engine = FlutterEngine(
      name: "LispKeyboardEngine",
      project: nil,
      allowHeadlessExecution: true
    )
    guard engine.run(withEntrypoint: "keyboardMain") else {
      showStartupError()
      return
    }

    flutterEngine = engine
    let channel = FlutterMethodChannel(
      name: "lispgen/keyboard",
      binaryMessenger: engine.binaryMessenger
    )
    keyboardChannel = channel
    channel.setMethodCallHandler { [weak self] call, result in
      guard let self else {
        result(
          FlutterError(
            code: "keyboard_unavailable",
            message: "The keyboard controller is no longer available.",
            details: nil
          )
        )
        return
      }

      switch call.method {
      case "insertText":
        guard let text = call.arguments as? String else {
          result(
            FlutterError(
              code: "invalid_arguments",
              message: "insertText requires a string.",
              details: nil
            )
          )
          return
        }
        self.textDocumentProxy.insertText(text)
        result(nil)

      case "deleteBackward":
        self.textDocumentProxy.deleteBackward()
        result(nil)

      case "advanceToNextInputMode":
        self.advanceToNextInputMode()
        result(nil)

      default:
        result(FlutterMethodNotImplemented)
      }
    }

    let flutterViewController = FlutterViewController(
      engine: engine,
      nibName: nil,
      bundle: nil
    )
    addChild(flutterViewController)
    flutterViewController.view.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(flutterViewController.view)
    NSLayoutConstraint.activate([
      flutterViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
      flutterViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
      flutterViewController.view.topAnchor.constraint(equalTo: view.topAnchor),
      flutterViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
    ])
    flutterViewController.didMove(toParent: self)
  }

  private func showStartupError() {
    let message = UILabel()
    message.text = "Lisp Keyboard could not start."
    message.textAlignment = .center
    message.textColor = .secondaryLabel
    message.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(message)
    NSLayoutConstraint.activate([
      message.centerXAnchor.constraint(equalTo: view.centerXAnchor),
      message.centerYAnchor.constraint(equalTo: view.centerYAnchor),
    ])
  }
}
