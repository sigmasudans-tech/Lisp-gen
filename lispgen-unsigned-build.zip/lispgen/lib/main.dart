import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _keyboardChannel = MethodChannel('lispgen/keyboard');

void main() => runApp(const LispKeyboardApp());

@pragma('vm:entry-point')
void keyboardMain() => runApp(const LispKeyboardApp(isKeyboardExtension: true));

class LispKeyboardApp extends StatelessWidget {
  const LispKeyboardApp({super.key, this.isKeyboardExtension = false});

  final bool isKeyboardExtension;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lisp Keyboard',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3478F6),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3478F6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: isKeyboardExtension
          ? const LispKeyboard()
          : const KeyboardSetupPage(),
    );
  }
}

class KeyboardSetupPage extends StatelessWidget {
  const KeyboardSetupPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lisp Keyboard')),
      body: const Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.keyboard_alt_outlined, size: 48),
            SizedBox(height: 20),
            Text(
              'Enable the keyboard',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 12),
            Text(
              'Open Settings > General > Keyboard > Keyboards > Add New '
              'Keyboard, then choose Lisp Keyboard. In a text field, use the '
              'globe key to switch to it.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            SizedBox(height: 12),
            Text(
              'Typing is processed on-device. Full Access is not needed.',
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}

@immutable
class KeyEdit {
  const KeyEdit({this.deleteBefore = 0, this.text = ''});

  final int deleteBefore;
  final String text;
}

class LispKeyProcessor {
  String? _previousKey;
  int _previousOutputLength = 0;

  KeyEdit typeCharacter(String key) {
    final previous = _previousKey;
    if (previous != null && _isDigraph(previous, key)) {
      final previousOutputLength = _previousOutputLength;
      final output = _translateDigraph(previous, key);
      _previousKey = key;
      _previousOutputLength = output.length;
      return KeyEdit(deleteBefore: previousOutputLength, text: output);
    }

    final output = _translateSingle(key);
    _previousKey = key;
    _previousOutputLength = output.length;
    return KeyEdit(text: output);
  }

  void reset() {
    _previousKey = null;
    _previousOutputLength = 0;
  }

  bool _isDigraph(String first, String second) {
    return const {'s', 'z', 'c'}.contains(first.toLowerCase()) &&
        second.toLowerCase() == 'h';
  }

  String _translateSingle(String key) {
    if (key.toLowerCase() == 's' || key.toLowerCase() == 'z') {
      return key == key.toUpperCase() ? 'Th' : 'th';
    }
    return key;
  }

  String _translateDigraph(String first, String second) {
    final allUpper =
        first == first.toUpperCase() && second == second.toUpperCase();
    final initialUpper = first == first.toUpperCase();
    if (allUpper) {
      return 'TH';
    }
    return initialUpper ? 'Th' : 'th';
  }
}

class LispKeyboard extends StatefulWidget {
  const LispKeyboard({super.key});

  @override
  State<LispKeyboard> createState() => _LispKeyboardState();
}

class _LispKeyboardState extends State<LispKeyboard> {
  final LispKeyProcessor _processor = LispKeyProcessor();
  Future<void> _pendingOperations = Future<void>.value();
  bool _shifted = false;
  bool _symbols = false;
  String? _bridgeError;

  bool get _isDark => Theme.of(context).brightness == Brightness.dark;

  void _enqueue(Future<void> Function() operation) {
    _pendingOperations = _pendingOperations.then((_) async {
      if (_bridgeError != null) {
        return;
      }
      try {
        await operation();
      } on MissingPluginException {
        _showBridgeError('Keyboard bridge is unavailable.');
      } on PlatformException catch (error) {
        _showBridgeError(error.message ?? 'Keyboard action failed.');
      }
    });
  }

  void _showBridgeError(String message) {
    if (mounted) {
      setState(() => _bridgeError = message);
    }
  }

  Future<void> _typeCharacter(String key) async {
    final edit = _processor.typeCharacter(key);
    for (var index = 0; index < edit.deleteBefore; index++) {
      await _keyboardChannel.invokeMethod<void>('deleteBackward');
    }
    if (edit.text.isNotEmpty) {
      await _keyboardChannel.invokeMethod<void>('insertText', edit.text);
    }
  }

  void _pressCharacter(String key) {
    final value = _symbols ? key : (_shifted ? key.toUpperCase() : key);
    _enqueue(() => _typeCharacter(value));
    if (!_symbols && _shifted) {
      setState(() => _shifted = false);
    }
  }

  void _pressBackspace() {
    _enqueue(() async {
      _processor.reset();
      await _keyboardChannel.invokeMethod<void>('deleteBackward');
    });
  }

  void _pressText(String text) {
    _enqueue(() async {
      _processor.reset();
      await _keyboardChannel.invokeMethod<void>('insertText', text);
    });
    if (text == ' ') {
      setState(() => _shifted = false);
    }
  }

  void _pressNextKeyboard() {
    _enqueue(() async {
      _processor.reset();
      await _keyboardChannel.invokeMethod<void>('advanceToNextInputMode');
    });
  }

  void _toggleSymbols() {
    setState(() => _symbols = !_symbols);
    _enqueue(() async => _processor.reset());
  }

  void _pressShift() {
    if (_symbols) {
      setState(() => _symbols = false);
      _enqueue(() async => _processor.reset());
      return;
    }
    setState(() => _shifted = !_shifted);
  }

  @override
  Widget build(BuildContext context) {
    final rows = _symbols
        ? const [
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
            ['@', '#', r'$', '&', '*', '-', '+', '(', ')', '/'],
            [':', ';', '"', "'", '!', '?'],
          ]
        : const [
            ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
            ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
            ['z', 'x', 'c', 'v', 'b', 'n', 'm'],
          ];

    return Scaffold(
      backgroundColor: _isDark
          ? const Color(0xFF17191D)
          : const Color(0xFFD1D5DB),
      body: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(3, 7, 3, 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_bridgeError case final error?)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    error,
                    style: TextStyle(
                      color: _isDark ? Colors.white70 : Colors.black54,
                      fontSize: 12,
                    ),
                  ),
                ),
              for (var index = 0; index < rows.length; index++)
                _buildLetterRow(rows[index], index),
              const SizedBox(height: 7),
              _buildBottomRow(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLetterRow(List<String> letters, int rowIndex) {
    final children = <Widget>[];
    if (rowIndex == 2) {
      children.add(
        _KeyButton(
          label: _symbols ? '=\\<' : '',
          icon: _symbols ? null : Icons.arrow_upward,
          modifier: true,
          onPressed: _pressShift,
        ),
      );
    } else if (rowIndex == 1) {
      children.add(const Spacer(flex: 2));
    }

    for (final letter in letters) {
      children.add(
        _KeyButton(
          label: _symbols || !_shifted ? letter : letter.toUpperCase(),
          onPressed: () => _pressCharacter(letter),
        ),
      );
    }

    if (rowIndex == 2) {
      children.add(
        _KeyButton(
          label: '',
          icon: Icons.backspace_outlined,
          modifier: true,
          onPressed: _pressBackspace,
        ),
      );
    } else if (rowIndex == 1) {
      children.add(const Spacer(flex: 2));
    }

    return Padding(
      padding: EdgeInsets.only(bottom: rowIndex == 2 ? 0 : 7),
      child: Row(children: children),
    );
  }

  Widget _buildBottomRow() {
    return Row(
      children: [
        _KeyButton(
          label: '',
          icon: Icons.language,
          modifier: true,
          onPressed: _pressNextKeyboard,
        ),
        _KeyButton(
          label: _symbols ? 'ABC' : '123',
          modifier: true,
          flex: 2,
          onPressed: _toggleSymbols,
        ),
        _KeyButton(
          label: ',',
          modifier: true,
          onPressed: () => _pressCharacter(','),
        ),
        _KeyButton(label: 'space', flex: 5, onPressed: () => _pressText(' ')),
        _KeyButton(
          label: '.',
          modifier: true,
          onPressed: () => _pressCharacter('.'),
        ),
        _KeyButton(
          label: 'return',
          modifier: true,
          flex: 2,
          onPressed: () => _pressText('\n'),
        ),
      ],
    );
  }
}

class _KeyButton extends StatelessWidget {
  const _KeyButton({
    required this.label,
    required this.onPressed,
    this.icon,
    this.modifier = false,
    this.flex = 1,
  });

  final String label;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool modifier;
  final int flex;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final background = modifier
        ? (dark ? const Color(0xFF555A64) : const Color(0xFFAEB4BE))
        : (dark ? const Color(0xFF343840) : Colors.white);

    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: SizedBox(
          height: 43,
          child: Material(
            color: background,
            borderRadius: BorderRadius.circular(5),
            elevation: modifier ? 0 : 1,
            child: InkWell(
              borderRadius: BorderRadius.circular(5),
              onTap: onPressed,
              child: Center(
                child: icon == null
                    ? Text(
                        label,
                        maxLines: 1,
                        style: TextStyle(
                          color: dark ? Colors.white : const Color(0xFF22252A),
                          fontSize: label.length > 3 ? 13 : 20,
                          fontWeight: FontWeight.w500,
                        ),
                      )
                    : Icon(
                        icon,
                        color: dark ? Colors.white : const Color(0xFF22252A),
                        size: 20,
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
