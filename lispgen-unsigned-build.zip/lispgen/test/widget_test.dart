import 'package:flutter_test/flutter_test.dart';
import 'package:lispgen/main.dart';

void main() {
  group('LispKeyProcessor', () {
    test('transforms single s and z characters', () {
      final processor = LispKeyProcessor();

      expect(processor.typeCharacter('s').text, 'th');
      processor.reset();
      expect(processor.typeCharacter('z').text, 'th');
      processor.reset();
      expect(processor.typeCharacter('S').text, 'Th');
      processor.reset();
      expect(processor.typeCharacter('Z').text, 'Th');
    });

    test('replaces sh, zh and ch digraphs', () {
      for (final first in ['s', 'z', 'c']) {
        final processor = LispKeyProcessor();
        final firstEdit = processor.typeCharacter(first);
        final secondEdit = processor.typeCharacter('h');

        expect(secondEdit.deleteBefore, first == 'c' ? 1 : 2);
        expect(secondEdit.text, 'th');
        expect(firstEdit.text, first == 'c' ? 'c' : 'th');
      }
    });

    test('preserves title and uppercase digraph case', () {
      final processor = LispKeyProcessor();

      expect(processor.typeCharacter('S').text, 'Th');
      expect(processor.typeCharacter('H').text, 'TH');

      processor.reset();
      expect(processor.typeCharacter('C').text, 'C');
      expect(processor.typeCharacter('H').text, 'TH');
    });

    testWidgets('keyboard setup page renders in the host app', (tester) async {
      await tester.pumpWidget(const LispKeyboardApp());

      expect(find.text('Enable the keyboard'), findsOneWidget);
      expect(
        find.textContaining('Settings > General > Keyboard'),
        findsOneWidget,
      );
    });
  });
}
