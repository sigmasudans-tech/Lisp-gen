# Lisp Keyboard

This Flutter project contains a keyboard UI, a pure-Dart lisp key processor, and
the native iOS keyboard-extension controller. The keyboard translates `s` and
`z` to `th` and `sh`, `zh`, and `ch` to `th`, preserving initial/all-uppercase
forms (`Th`/`TH`). Digraph input replaces the preceding output through the
native text proxy.

## Flutter setup

```powershell
flutter pub get
flutter test
flutter analyze
```

The host app is an onboarding screen. The extension enters Flutter at the
`keyboardMain` Dart entry point in `lib/main.dart`. No Flutter plugins or
network access are needed by the keyboard.

## Add the iOS keyboard extension

Do this on macOS with Xcode; iOS extensions cannot be built or signed from
Windows.

1. Open `ios/Runner.xcworkspace` in Xcode and select **File > New > Target**.
   Choose **iOS > Custom Keyboard Extension**. Name the target `LispKeyboard`
   and use the same iOS deployment target as Runner (currently iOS 15).
2. Replace the generated controller with
   [`ios/KeyboardExtension/KeyboardViewController.swift`](ios/KeyboardExtension/KeyboardViewController.swift).
   Set the extension target's Info.plist to
   [`ios/KeyboardExtension/Info.plist`](ios/KeyboardExtension/Info.plist), or
   copy its `NSExtension` dictionary into the generated plist. Add the Swift
   file to the extension target's **Target Membership**.
3. Set the extension bundle identifier to a child of Runner's, for example
   `com.example.lispgen.LispKeyboard`. Set the development team and signing
   identity for both targets. Keep `RequestsOpenAccess` set to `NO`; this
   keyboard does not need Full Access.
4. Ensure the extension is embedded in Runner under **Build Phases > Embed App
   Extensions** (Xcode normally adds this when creating the target). The
   extension's principal class must resolve to
   `$(PRODUCT_MODULE_NAME).KeyboardViewController`.
5. Link Flutter into the extension target and include the compiled Flutter
   Dart application and assets in the extension's runtime bundle. The native
   controller starts `keyboardMain` using `FlutterEngine` and requires both
   `Flutter.framework` and the matching `App.framework` to be available to the
   extension at runtime. Runner's current generated Swift Package integration
   does **not** automatically add Flutter to a new extension target. Configure
   the extension with Flutter's current iOS add-to-app/build integration,
   including framework embedding/signing and a build dependency that keeps
   `App.framework` in sync with `lib/main.dart`. Do not add the Runner app
   target's `AppDelegate` or plugin registrant to the extension.
6. Build and install Runner on a physical iOS device. In **Settings > General >
   Keyboard > Keyboards > Add New Keyboard**, enable **Lisp Keyboard**. In a
   text field, tap the globe key to select it.

### Flutter-in-an-extension caveat

Flutter does not configure a keyboard extension as part of the standard
`flutter create` iOS build. A custom Xcode target and a validated embedding
build phase are required; merely adding the Swift file will not make the
extension launchable. Flutter's engine and Dart UI also consume substantially
more memory than a native keyboard, and iOS may terminate a keyboard extension
under memory pressure. Verify framework extension-safety, signing, memory use,
and App Store requirements on supported devices before shipping. For a
production keyboard where reliability and launch time are priorities, implement
the key UI in UIKit/Swift and keep Flutter for the companion/settings app.

## Bridge and platform behavior

The extension creates a lightweight `FlutterEngine` and a
`FlutterViewController`. On `lispgen/keyboard`, Flutter sends `insertText`,
`deleteBackward`, or `advanceToNextInputMode`; Swift forwards those operations
to `textDocumentProxy`. Key edits are serialized so digraph replacement
(delete prior translated characters, then insert `th`) remains ordered.

iOS does not allow a third-party keyboard to intercept keystrokes while another
keyboard is selected. This extension only receives taps when the user has
selected Lisp Keyboard. Secure text fields and some host apps use or require the
system keyboard, and a keyboard cannot control whether a host app permits it.
The keyboard does not record or transmit typed text.
